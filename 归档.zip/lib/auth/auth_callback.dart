import 'dart:async';

typedef Future AuthCallback(context);