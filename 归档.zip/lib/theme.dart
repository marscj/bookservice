import 'package:flutter/material.dart';

const kShrineSurfaceWhite = const Color(0xFFFFFBFA);
// const kShrineBackgroundWhite = Colors.white;

const Color kFlutterBlue = Color(0xFF003D75);