// import 'dart:async';

// import './http/http_loader.dart';

// Future<String> get hello => HttpLoader.instance.hello;

// Future<String> setCustomClaims(data) => HttpLoader.instance.setCustomClaims(data);